// Problem 1
// function getAvg(arr) {
//     let totalNb = arr.length;
//     let sum = 0;
//     let avg = 0;
//     for(let i = 0; i < arr.length; i++) {
//         sum += arr[i]
//     }
//     console.log(sum)
//     avg = sum / totalNb
//     return avg
// }
// const newArr = [1,2,3]
// console.log(getAvg(newArr));

// Problem 2
function search (arr, nb) {
    for(let i =0; i < arr.length; i++) {
        if(nb == arr[i]) {
            return true;
        } 
    }
    return false;
}
// const newArr = [0,1,2,3,4,5];
// console.log(search(newArr, 4));
// console.log(search(newArr, 8));

// Problem 3
// function removeDublicates(arr) {
//     for (let i =0; i< arr.length; i++) {
//         if (arr[i] == arr[i+1]){
//             arr.splice(i,1)
//         }
//     }
//     return arr
// }
// const newArr = [0,1,2,3,3,5];
// const newArr = [0,1,2,3,3,5,5,6,7,8,8];
// console.log(removeDublicates(newArr))

// Problem 4
// function getMinMax (arr, word) {
//     let max = 0;
//     if (word == "max"){
//         for(let i =0; i < arr.length; i++) {
//             if(arr[i] > max) {
//                 max = arr[i];
//             }
//         }
//         return max
//     } else if (word == "min") {
//         let min = arr[0];
//         for(let i =0; i < arr.length; i++) {
//             if(arr[i] < min) {
//                 min = arr[i];
//             }
//         }
//         return min
//     } else {
//        return console.log("enter min or max man")
//     }
// }
// const newArr = [0,2,3,4,5];
// console.log(getMinMax(newArr, "max"));
// console.log(getMinMax(newArr, "min"));
// console.log(getMinMax(newArr, "asdasd"));

// Problem 6
// function intersect(arr1, arr2) {
//    var arr4 = [];
//     for (let j = 0; j < arr2.length; j++){
//         if(search(arr1, arr2[j])){
//             arr4.push(arr2[j])
//         }
//     }
        
//        return arr4
        
// }
// const arr1 = [0, 1, 2, 3, 4, 5];
// const arr2 = [4, 5, 6, 7, 8, 9, 0];
// console.log(intersect(arr1, arr2))