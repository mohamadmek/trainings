    var arr = [];
    let nameBtn = document.querySelector('.nameBtn');
    let name = document.querySelector('.name');
    let listOfNames = document.querySelector('.listOfNames');
    let groupNB = document.querySelector('.number');
    let generate = document.querySelector('.generate');
    let first = document.querySelector('#first');
    let sec = document.querySelector('.sec');
    function shuffle(array) { array.sort(() => Math.random() - 0.5);}

      
    nameBtn.addEventListener('click',function() {
        arr.push(name.value);
        name.value='';
          listOfNames.innerHTML += `<div>${arr[arr.length-1]}</div>`
      
        
    })
  
    arr.forEach(name => {
        listOfNames.innerHTML += `<div>${name}</div>`
    })
   
    
    function show() {
      let newArr = [];
      let i = 0;
      let len = parseInt(groupNB.value);
      shuffle(arr);
      while(i < arr.length) {
        newArr.push(arr.slice(i, i + len));
        i += len;
    }
      for(let p = 0; p < newArr.length; p++) {
        sec.innerHTML += `
        <div  style="display:block">Team ${p+1}</div>
        <div  style="flex: 1; background-color: blue; margin-right:10px;">
          ${newArr[p].join('<br>')}
        </div>
        `
    }
    return sec
    
  }
    generate.addEventListener('click', function(){
      let wrap = document.querySelector('.wrap');
      if(sec.innerHTML != null){
        sec.innerHTML = '';
        show();
      } else {
        show();
      }
      
      
      })

    
    


